from PIL import Image
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.Random import get_random_bytes
import rsa
import time
import socket
import base64

# Set up TLS connection with ATM user
print("Initialising....")
time.sleep(1)

s = socket.socket()
host = socket.gethostname()
ip = "192.168.56.1"
port = 1234
s.bind((host, port))
print(host, "(", ip, ")\n")
name = "Bank"

s.listen(1)
print("Waiting for incoming connections...")
conn, addr = s.accept()
print("Received connection from", addr[0], "(", addr[1], ")")

s_name = conn.recv(1024)
s_name = s_name.decode()
print(s_name, "has connected via TLS\n")
conn.send(name.encode())

# TLS connection 2 - Request public key from user
message = 'Request public key from user'
print(message)
conn.send(message.encode())

# TLS connection 3 - Receive public key from user
message = conn.recv(1024)
public_key = message.decode()
print('User public key received.')

# TLS connection 4 - Send user RSA encrypted session key - key: 'Sample AES Key ABCDEF'
session_key = get_random_bytes(16)
aes_key = 'sampleaeskeyabcdef'
print("Session key to encrypt image will be: ", session_key)

# Encrypt the session key with the public RSA key
cipher_rsa = PKCS1_OAEP.new(public_key)
enc_session_key = cipher_rsa.encrypt(session_key)
print('AES key encrypted and being sent...')
conn.send(enc_session_key.encode())

# TLS connection 5 - Wait to receive ACK from user
message = conn.recv(1024)
message = message.decode()
if message != "ACK":
    print("Error, have not received user ACK. Exiting...")
    exit()
print("User: Encrypted session key received!\n")

# TLS connection 6 - Encrypt the reCAPTCHA image via AES ECB mode and send to user

# Check if the image we are sending exists
img_name = "recaptcha_example.png"
try:
    img = Image.open(img_name)
    #img.show()
except IOError:
    print("Error, couldn't locate image with that name, try again.")
    pass

# Convert image to string, this way it can be encrypted and sent over TLS
with open(img_name, "rb") as image:
    b64string = base64.b64encode(image.read())

# Encrypt image via ECB encryption and send
cipher = AES.new(aes_key, AES.MODE_ECB)
message = cipher.encrypt(b64string)
print('reCAPTCHA image encrypted via AES ECB Mode. Sending to user...')
conn.send(message.encode())
