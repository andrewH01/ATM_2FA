# Python program to  create a simple GUI
# calculator using Tkinter

# import everything from tkinter module
from tkinter import *


# Function to result of reCAPTCHA
def press(btn):
    #Change the color of the boxes that the user selects
    if (btn["bg"] == 'white'):
        btn["bg"] = 'purple'
    else:
        btn["bg"] = 'white'


def submit_results():
    #Come up with a way to store the result of the users reCAPTCHA
    #Then need to send that over the socket (or however TLS works) back to the bank
    results = []

    if button1["bg"] == 'white':    results.append(1)
    else:                           results.append(0)
    if button2["bg"] == 'white':    results.append(1)
    else:                           results.append(0)
    if button3["bg"] == 'white':    results.append(1)
    else:                           results.append(0)
    if button4["bg"] == 'white':    results.append(1)
    else:                           results.append(0)
    if button5["bg"] == 'white':    results.append(1)
    else:                           results.append(0)
    if button6["bg"] == 'white':    results.append(1)
    else:                           results.append(0)
    if button7["bg"] == 'white':    results.append(1)
    else:                           results.append(0)
    if button8["bg"] == 'white':    results.append(1)
    else:                           results.append(0)
    if button9["bg"] == 'white':    results.append(1)
    else:                           results.append(0)
    if button10["bg"] == 'white':    results.append(1)
    else:                           results.append(0)
    if button11["bg"] == 'white':    results.append(1)
    else:                           results.append(0)
    if button12["bg"] == 'white':    results.append(1)
    else:                           results.append(0)
    if button13["bg"] == 'white':    results.append(1)
    else:                           results.append(0)
    if button14["bg"] == 'white':    results.append(1)
    else:                           results.append(0)
    if button15["bg"] == 'white':    results.append(1)
    else:                           results.append(0)
    if button16["bg"] == 'white':    results.append(1)
    else:                           results.append(0)

    print('\nResult to send to bank network: ', results)

    exit()


# Driver code
if __name__ == "__main__":
    # create a GUI window
    gui = Tk()

    # set the background colour of GUI window
    gui.configure(background='light blue')

    # set the title of GUI window
    gui.title('ATM reCAPTCHA Simulation')

    # set the configuration of GUI window
    gui.geometry("655x710")

    # Thing in the reCAPTCHA that the user will have to select on the ATM grid
    search_term = "traffic lights"

    # create the text entry box for
    # showing the expression .
    # globally declare the expression variable
    instruction_field = StringVar()
    instructions = "Please select all of the images with: " + search_term
    instruction_field.set(instructions)
    instruction_label = Label(gui, textvariable=instruction_field)

    # grid method is used for placing
    # the widgets at respective positions
    # in table like structure .
    instruction_label.grid(columnspan=4, ipadx=200)

    # create a Buttons and place at a particular
    # location inside the root window .
    # when user press the button, the command or
    # function affiliated to that button is executed .
    button1 = Button(gui, bg='purple', command=lambda: press(button1), height=10, width=22)
    button1.grid(row=2, column=0)

    button2 = Button(gui, bg='purple', command=lambda: press(button2), height=10, width=22)
    button2.grid(row=2, column=1)

    button3 = Button(gui, bg='purple', command=lambda: press(button3), height=10, width=22)
    button3.grid(row=2, column=2)

    button4 = Button(gui, bg='purple', command=lambda: press(button4), height=10, width=22)
    button4.grid(row=2, column=3)

    button5 = Button(gui, bg='purple', command=lambda: press(button5), height=10, width=22)
    button5.grid(row=3, column=0)

    button6 = Button(gui, bg='purple', command=lambda: press(button6), height=10, width=22)
    button6.grid(row=3, column=1)

    button7 = Button(gui, bg='purple', command=lambda: press(button7), height=10, width=22)
    button7.grid(row=3, column=2)

    button8 = Button(gui, bg='purple', command=lambda: press(button8), height=10, width=22)
    button8.grid(row=3, column=3)

    button9 = Button(gui, bg='purple', command=lambda: press(button9), height=10, width=22)
    button9.grid(row=4, column=0)

    button10 = Button(gui, bg='purple', command=lambda: press(button10), height=10, width=22)
    button10.grid(row=4, column=1)

    button11 = Button(gui, bg='purple', command=lambda: press(button11), height=10, width=22)
    button11.grid(row=4, column=2)

    button12 = Button(gui, bg='purple', command=lambda: press(button12), height=10, width=22)
    button12.grid(row=4, column=3)

    button13 = Button(gui, bg='purple', command=lambda: press(button13), height=10, width=22)
    button13.grid(row=5, column=0)

    button14 = Button(gui, bg='purple', command=lambda: press(button14), height=10, width=22)
    button14.grid(row=5, column=1)

    button15 = Button(gui, bg='purple', command=lambda: press(button15), height=10, width=22)
    button15.grid(row=5, column=2)

    button16 = Button(gui, bg='purple', command=lambda: press(button16), height=10, width=22)
    button16.grid(row=5, column=3)

    submit = Button(gui, text="Submit", command=lambda: submit_results(), bg='blue', height=2, width=12)
    submit.grid(row=7, column=3)

    # start the GUI
    gui.mainloop()