import rsa
from PIL import Image
from Crypto.Cipher import AES, PKCS1_OAEP
import rsa
import io
import time
import socket
import base64

# Set up user public and private keys
public_key, private_key = rsa.newkeys(1024)

# Enter TLS connection with Bank
print("Initialising....\n")
time.sleep(1)

s = socket.socket()
shost = socket.gethostname()
ip = socket.gethostbyname(shost)
host = "192.168.56.1"
name = "User"
port = 1234
time.sleep(1)
s.connect((host, port))
print("Connected...\n")

s.send(name.encode())
s_name = s.recv(1024)
s_name = s_name.decode()
print(s_name, "has connected via TLS\n")

# TLS connection 2 - Receive server request for public key
message = s.recv(1024)
message = message.decode()
print(s_name, ":", message)

# TLS connection 3 - Send server public key
print('Sending public key to server...')
s.send(message.encode())

# TLS connection 4 - Receive encrypted session key from server
print("\nReceiving encrypted session key from bank network...")
message = s.recv(1024)
message = message.decode()

# Decrypt the session key with the private RSA key
cipher_rsa = PKCS1_OAEP.new(private_key)
session_key = cipher_rsa.decrypt(message)
print("ACK")

# TLS connection 5 - Acknowledge session key is received
print("Sending ACK to server...")
message = 'ACK'
s.send(message.encode())

# TLS connection 6 - Receive and decrypt once encrypted image is received
message = s.recv(1024)
message = message.decode()
print("Encrypted image received. Decrypting... ")

decipher = AES.new(session_key, AES.MODE_ECB)
img = decipher.decrypt(message)
img = io.BytesIO(base64.b64decode(message))

# Attempt to view decrypted image
img = Image.open(img)
img.show()
